#!/usr/bin/env python3
"""
CRISCAN - Critical Infrastructure Security Scanner
Made with ❤️ by IoTSRG Team
"""

import argparse, csv, html, json, os, re, shutil, subprocess, sys, time
from typing import List, Dict, Any, Tuple, Optional

__version__ = "2.0.0"
TOOL_NAME = "CRISCAN"
TOOL_FULL = "Critical Infrastructure Security Scanner"

PROFILES = {
    "medical": {"name": "Medical Device Audit (FDA 524B)", "icon": "🏥", "description": "FDA cybersecurity requirements", "categories": ["BOOT", "ENCRYPTION", "NETWORK", "APPS", "TEE", "PATCHING", "PRIVACY", "MEDICAL"]},
    "automotive": {"name": "Automotive Audit (ISO 21434)", "icon": "🚗", "description": "Connected vehicle security", "categories": ["BOOT", "AVB", "DM-VERITY", "BOOTLOADER", "BLUETOOTH", "NETWORK", "OTA", "AUTOMOTIVE"]},
    "industrial": {"name": "Industrial IoT Audit (IEC 62443)", "icon": "🏭", "description": "Industrial control security", "categories": ["BOOT", "SELINUX", "NETWORK", "KERNEL", "MEMORY", "FILESYSTEM", "INDUSTRIAL"]},
    "full": {"name": "Full Security Audit", "icon": "🔒", "description": "Comprehensive audit", "categories": []}
}

def which(p): return shutil.which(p)
def run(cmd, timeout=60):
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = proc.communicate(timeout=timeout)
        return proc.returncode, out, err
    except: return -1, "", "error"

def list_adb_devices():
    code, out, _ = run(["adb", "devices", "-l"])
    if code != 0: return []
    devs = []
    for ln in out.splitlines()[1:]:
        if ln.strip():
            p = ln.split()
            devs.append({"serial": p[0], "state": p[1] if len(p)>1 else "unknown", "desc": " ".join(p[2:]) if len(p)>2 else ""})
    return devs

def pick_default_serial(user_serial):
    if user_serial: return user_serial
    devs = [d for d in list_adb_devices() if d["state"] == "device"]
    return devs[0]["serial"] if len(devs) == 1 else None

def explain_adb_devices_and_exit(code=2):
    devs = list_adb_devices()
    if not devs:
        print("\n⚠️  No ADB devices. Enable USB debugging and connect device.\n", file=sys.stderr)
    else:
        print("\n┌─ ADB Devices (use --serial) ─┐")
        for d in devs: print(f"│ {'✓' if d['state']=='device' else '✗'} {d['serial']:<20} {d['state']:<10} │")
        print("└──────────────────────────────┘\n")
    sys.exit(code)

class ADB:
    def __init__(self, serial=None): self.serial = serial
    def base(self): return ["adb"] + (["-s", self.serial] if self.serial else [])
    def check_connected(self):
        code, out, _ = run(self.base() + ["get-state"])
        if code != 0: raise RuntimeError("No ADB device")
    def shell(self, cmd, timeout=30):
        _, out, _ = run(self.base() + ["shell", cmd], timeout)
        return (out or "").replace("\r", "").strip()

def get_prop_fallback(adb, props):
    for p in props:
        v = adb.shell(f"getprop {p}")
        if v: return v
    return "(unknown)"

def collect_device_info(adb):
    return {
        "model": get_prop_fallback(adb, ["ro.product.model", "ro.product.device"]),
        "brand": get_prop_fallback(adb, ["ro.product.brand"]),
        "manufacturer": get_prop_fallback(adb, ["ro.product.manufacturer"]),
        "android_version": adb.shell("getprop ro.build.version.release"),
        "sdk_level": adb.shell("getprop ro.build.version.sdk"),
        "build_id": adb.shell("getprop ro.build.display.id"),
        "fingerprint": adb.shell("getprop ro.build.fingerprint"),
        "serialno": get_prop_fallback(adb, ["ro.serialno", "ro.boot.serialno"]),
        "security_patch": adb.shell("getprop ro.build.version.security_patch"),
        "kernel_version": adb.shell("uname -r"),
        "build_type": adb.shell("getprop ro.build.type"),
    }

def load_checks_from_file(path):
    with open(path, "r", encoding="utf-8") as f: data = json.load(f)
    if isinstance(data, list): return data
    if isinstance(data, dict) and "checks" in data: return data["checks"]
    raise ValueError(f"Invalid JSON: {path}")

def load_checks_from_dir(folder):
    if not os.path.isdir(folder): raise FileNotFoundError(f"Not found: {folder}")
    checks = []
    for name in sorted(os.listdir(folder)):
        if name.endswith(".json"):
            try: checks.extend(load_checks_from_file(os.path.join(folder, name)))
            except Exception as e: print(f"[WARN] {name}: {e}", file=sys.stderr)
    return checks

def filter_checks_by_profile(checks, profile):
    if profile not in PROFILES or not PROFILES[profile]["categories"]: return checks
    allowed = [c.upper() for c in PROFILES[profile]["categories"]]
    return [c for c in checks if any(a in c.get("category","").upper() for a in allowed)] or checks

def bucket_from_level(level):
    l = (level or "").lower()
    if l in ("critical", "high"): return "critical"
    if l in ("warning", "medium"): return "warning"
    return "info"

def run_checks(adb, checks, on_progress=None):
    rows, counts = [], {"safe": 0, "warning": 0, "critical": 0, "info": 0, "not_supported": 0}
    for idx, chk in enumerate(checks, 1):
        if on_progress: on_progress(idx, len(checks))
        cat, label, cmd = chk.get("category",""), chk.get("label",""), chk.get("command","")
        safe_pat, level, desc = chk.get("safe_pattern",".*"), chk.get("level","info"), chk.get("description","")
        compliance, cves = chk.get("compliance",{}), chk.get("cve_related",[])
        
        raw = adb.shell(cmd) or "[Not Supported]"
        try: matched = bool(re.search(safe_pat, re.sub(r"\r?\n+", " ", raw), re.DOTALL))
        except: matched = False
        
        if raw == "[Not Supported]":
            status, bucket = "INFO", "info"; counts["not_supported"] += 1
        elif matched:
            status, bucket = "SAFE", "safe"; counts["safe"] += 1
        else:
            bucket = bucket_from_level(level)
            status = {"critical": "CRITICAL", "warning": "WARNING"}.get(bucket, "INFO")
            counts[bucket] += 1
        
        rows.append({"timestamp": time.strftime("%Y-%m-%d %H:%M:%S"), "category": cat, "label": label,
            "level": level, "bucket": bucket, "status": status, "matched": str(matched),
            "command": cmd, "result": raw, "description": desc, "compliance": compliance, "cve_related": cves})
    return rows, counts

def write_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, ["timestamp","category","label","level","bucket","status","matched","command","result","description"], extrasaction='ignore')
        w.writeheader(); [w.writerow(r) for r in rows]

def write_json(path, device, rows, counts, profile=None):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"tool": TOOL_NAME, "version": __version__, "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
            "profile": profile, "device": device, "summary": counts, "findings": rows}, f, indent=2)

def write_txt(path, device, rows, counts, profile=None):
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{'='*70}\n  {TOOL_NAME} - Security Audit Report\n{'='*70}\n")
        f.write(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        if profile: f.write(f"Profile: {profile}\n")
        f.write(f"\nDevice: {device.get('model')} | Android {device.get('android_version')} | Patch: {device.get('security_patch')}\n\n")
        for r in rows: f.write(f"[{r['status']}] {r['category']} - {r['label']}\n")
        f.write(f"\n{'='*70}\nSafe: {counts['safe']} | Warning: {counts['warning']} | Critical: {counts['critical']}\n{'='*70}\n")

def write_html(path, device, rows, counts, profile=None, duration="N/A"):
    esc = html.escape
    total = counts["safe"] + counts["warning"] + counts["critical"]
    score = max(0, min(100, round(((counts["safe"]*100)+(counts["warning"]*50)) / total))) if total > 0 else 0
    score_color = "#10b981" if score >= 70 else "#f59e0b" if score >= 50 else "#ef4444"
    gauge_offset = 440 - (440 * score / 100)
    
    profile_icon, profile_name = "🔒", "Full Security Audit"
    if profile and profile in PROFILES:
        profile_icon, profile_name = PROFILES[profile]["icon"], PROFILES[profile]["name"]
    
    categories = sorted(set(r["category"] for r in rows if r["category"]))
    cat_opts = "\n".join(f'<option value="{esc(c)}">{esc(c)}</option>' for c in categories)
    
    findings = ""
    for r in rows:
        sc = {"SAFE":"safe","WARNING":"warning","CRITICAL":"critical"}.get(r["status"], "info")
        tags = "".join(f'<span class="tag tag-compliance">{esc(k.upper())}</span>' for k in r.get("compliance",{}).keys())
        tags += "".join(f'<span class="tag tag-cve">{esc(c)}</span>' for c in r.get("cve_related",[]))
        findings += f'''<div class="finding-card {sc}" data-status="{sc}" data-category="{esc(r['category'])}">
<div class="finding-header" onclick="toggleFinding(this)"><div class="finding-main">
<div class="finding-category">{esc(r['category'])}</div><div class="finding-title">{esc(r['label'])}</div>
<div class="finding-desc">{esc(r['description'])}</div><div class="finding-tags">{tags}</div></div>
<span class="status-badge {sc}">{esc(r['status'])}</span></div>
<div class="finding-details"><div class="detail-block"><div class="detail-label">Command</div>
<div class="code-block">{esc(r['command'])}</div></div><div class="detail-block">
<div class="detail-label">Result</div><div class="code-block">{esc(r['result'])}</div></div></div></div>
'''

    html_doc = f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>CRISCAN Security Report</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root{{--bg-primary:#0f172a;--bg-secondary:#1e293b;--bg-tertiary:#334155;--text-primary:#f1f5f9;--text-secondary:#94a3b8;--text-muted:#64748b;--border-color:#334155;--safe:#10b981;--safe-bg:rgba(16,185,129,0.1);--safe-border:rgba(16,185,129,0.3);--warning:#f59e0b;--warning-bg:rgba(245,158,11,0.1);--warning-border:rgba(245,158,11,0.3);--critical:#ef4444;--critical-bg:rgba(239,68,68,0.1);--critical-border:rgba(239,68,68,0.3);--info:#3b82f6;--info-bg:rgba(59,130,246,0.1);--info-border:rgba(59,130,246,0.3);--accent:#6366f1}}
[data-theme="light"]{{--bg-primary:#f1f5f9;--bg-secondary:#fff;--bg-tertiary:#e2e8f0;--text-primary:#0f172a;--text-secondary:#475569;--text-muted:#94a3b8;--border-color:#e2e8f0}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Inter',sans-serif;background:var(--bg-primary);color:var(--text-primary);line-height:1.6}}
.container{{max-width:1400px;margin:0 auto;padding:0 24px}}
.header{{background:var(--bg-secondary);padding:32px 0;border-bottom:1px solid var(--border-color)}}
.header-top{{display:flex;align-items:center;gap:20px;margin-bottom:32px}}
.logo-icon{{width:56px;height:56px;background:linear-gradient(135deg,#fbbf24,#f59e0b);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:28px;box-shadow:0 4px 12px rgba(251,191,36,0.3)}}
.logo-text h1{{font-size:2rem;font-weight:800}}
.logo-text .tagline{{font-size:0.95rem;color:var(--text-secondary)}}
.header-meta{{display:flex;gap:48px;padding-top:24px;border-top:1px solid var(--border-color);flex-wrap:wrap}}
.meta-item{{display:flex;flex-direction:column;gap:4px}}
.meta-label{{font-size:0.7rem;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-muted);font-weight:600}}
.meta-value{{font-size:0.95rem;font-weight:600}}
.summary-section{{background:var(--bg-secondary);border-radius:16px;padding:32px;margin:24px 0;border:1px solid var(--border-color)}}
.summary-grid{{display:flex;align-items:center;gap:32px;flex-wrap:wrap}}
.risk-gauge-wrapper{{flex-shrink:0}}
.risk-gauge{{position:relative;width:160px;height:160px}}
.risk-gauge svg{{transform:rotate(-90deg)}}
.risk-gauge-bg{{fill:none;stroke:var(--bg-tertiary);stroke-width:10}}
.risk-gauge-fill{{fill:none;stroke-width:10;stroke-linecap:round}}
.risk-gauge-center{{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center}}
.risk-score-value{{font-size:2.75rem;font-weight:800;line-height:1}}
.risk-score-label{{font-size:0.8rem;color:var(--text-secondary);margin-top:4px}}
.stats-row{{display:flex;gap:16px;flex:1;flex-wrap:wrap}}
.stat-card{{flex:1;min-width:120px;background:var(--bg-primary);border-radius:12px;padding:24px 20px;text-align:center;border:2px solid transparent;transition:all 0.2s}}
.stat-card:hover{{transform:translateY(-2px)}}
.stat-card.safe{{border-color:var(--safe);background:var(--safe-bg)}}
.stat-card.warning{{border-color:var(--warning);background:var(--warning-bg)}}
.stat-card.critical{{border-color:var(--critical);background:var(--critical-bg)}}
.stat-card.info{{border-color:var(--info);background:var(--info-bg)}}
.stat-number{{font-size:2.5rem;font-weight:800;line-height:1}}
.stat-card.safe .stat-number{{color:var(--safe)}}
.stat-card.warning .stat-number{{color:var(--warning)}}
.stat-card.critical .stat-number{{color:var(--critical)}}
.stat-card.info .stat-number{{color:var(--info)}}
.stat-label{{font-size:0.85rem;color:var(--text-secondary);margin-top:8px;font-weight:500}}
.toolbar{{position:sticky;top:0;z-index:100;background:var(--bg-primary);padding:16px 0;border-bottom:1px solid var(--border-color)}}
.toolbar-inner{{display:flex;align-items:center;gap:12px;flex-wrap:wrap}}
.search-box{{flex:1;position:relative;min-width:250px}}
.search-box input{{width:100%;padding:12px 16px 12px 44px;background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:10px;font-size:0.9rem;color:var(--text-primary)}}
.search-box input::placeholder{{color:var(--text-muted)}}
.search-box input:focus{{outline:none;border-color:var(--accent)}}
.search-icon{{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--text-muted)}}
.filter-select{{padding:12px 16px;background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:10px;font-size:0.9rem;color:var(--text-primary);cursor:pointer}}
.btn{{padding:12px 20px;border:none;border-radius:10px;font-size:0.9rem;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:8px;transition:all 0.2s;white-space:nowrap}}
.btn-secondary{{background:var(--bg-secondary);color:var(--text-primary);border:1px solid var(--border-color)}}
.btn-secondary:hover{{background:var(--bg-tertiary)}}
.btn-primary{{background:var(--accent);color:#fff}}
.btn-primary:hover{{opacity:0.9}}
.main-content{{display:grid;grid-template-columns:300px 1fr;gap:24px;padding:24px 0 48px}}
@media(max-width:1024px){{.main-content{{grid-template-columns:1fr}}}}
.sidebar{{display:flex;flex-direction:column;gap:20px}}
.card{{background:var(--bg-secondary);border-radius:14px;padding:20px;border:1px solid var(--border-color)}}
.card-header{{display:flex;align-items:center;gap:12px;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border-color)}}
.card-icon{{font-size:1.25rem}}
.card-title{{font-size:0.95rem;font-weight:700}}
.device-grid{{display:grid;gap:14px}}
.device-item{{display:flex;flex-direction:column;gap:2px}}
.device-label{{font-size:0.7rem;text-transform:uppercase;letter-spacing:0.06em;color:var(--text-muted);font-weight:600}}
.device-value{{font-size:0.875rem;word-break:break-word}}
.chart-wrapper{{height:180px;position:relative}}
.findings-section h2{{font-size:1.25rem;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:12px}}
.findings-count{{background:var(--bg-tertiary);padding:4px 12px;border-radius:20px;font-size:0.8rem;font-weight:600;color:var(--text-secondary)}}
.findings-list{{display:flex;flex-direction:column;gap:12px}}
.finding-card{{background:var(--bg-secondary);border-radius:12px;overflow:hidden;border:1px solid var(--border-color);border-left:4px solid var(--border-color);transition:all 0.2s}}
.finding-card:hover{{border-color:var(--text-muted)}}
.finding-card.safe{{border-left-color:var(--safe)}}
.finding-card.warning{{border-left-color:var(--warning)}}
.finding-card.critical{{border-left-color:var(--critical)}}
.finding-card.info{{border-left-color:var(--info)}}
.finding-header{{padding:16px 20px;cursor:pointer;display:flex;justify-content:space-between;align-items:flex-start;gap:16px}}
.finding-main{{flex:1;min-width:0}}
.finding-category{{font-size:0.65rem;text-transform:uppercase;letter-spacing:0.1em;color:var(--text-muted);font-weight:700;margin-bottom:4px}}
.finding-title{{font-size:0.95rem;font-weight:600;margin-bottom:6px}}
.finding-desc{{font-size:0.85rem;color:var(--text-secondary);line-height:1.5}}
.finding-tags{{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}}
.tag{{padding:3px 8px;border-radius:4px;font-size:0.65rem;font-weight:600;text-transform:uppercase}}
.tag-compliance{{background:var(--info-bg);color:var(--info);border:1px solid var(--info-border)}}
.tag-cve{{background:var(--critical-bg);color:var(--critical);border:1px solid var(--critical-border)}}
.status-badge{{padding:6px 12px;border-radius:6px;font-size:0.7rem;font-weight:700;text-transform:uppercase;white-space:nowrap;flex-shrink:0}}
.status-badge.safe{{background:var(--safe-bg);color:var(--safe);border:1px solid var(--safe-border)}}
.status-badge.warning{{background:var(--warning-bg);color:var(--warning);border:1px solid var(--warning-border)}}
.status-badge.critical{{background:var(--critical-bg);color:var(--critical);border:1px solid var(--critical-border)}}
.status-badge.info{{background:var(--info-bg);color:var(--info);border:1px solid var(--info-border)}}
.finding-details{{display:none;padding:16px 20px;background:var(--bg-primary);border-top:1px solid var(--border-color)}}
.finding-card.expanded .finding-details{{display:block}}
.detail-block{{margin-bottom:16px}}
.detail-block:last-child{{margin-bottom:0}}
.detail-label{{font-size:0.7rem;text-transform:uppercase;letter-spacing:0.06em;color:var(--text-muted);font-weight:700;margin-bottom:6px}}
.code-block{{background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:8px;padding:12px 14px;font-family:'JetBrains Mono',monospace;font-size:0.8rem;color:var(--text-secondary);overflow-x:auto;white-space:pre-wrap;word-break:break-word}}
.footer{{background:var(--bg-secondary);border-top:1px solid var(--border-color);padding:24px 0;text-align:center}}
.footer p{{color:var(--text-secondary);font-size:0.85rem;margin:4px 0}}
.footer a{{color:var(--accent);text-decoration:none}}
@media(max-width:900px){{.summary-grid{{flex-direction:column}}.risk-gauge-wrapper{{display:flex;justify-content:center}}}}
@media print{{.toolbar{{display:none}}.finding-details{{display:block!important}}body{{background:#fff;color:#000}}}}
</style></head>
<body>
<header class="header"><div class="container">
<div class="header-top"><div class="logo-icon">🔒</div>
<div class="logo-text"><h1>CRISCAN</h1><div class="tagline">Critical Infrastructure Security Scanner</div></div></div>
<div class="header-meta">
<div class="meta-item"><span class="meta-label">Generated</span><span class="meta-value">{time.strftime("%Y-%m-%d %H:%M:%S")}</span></div>
<div class="meta-item"><span class="meta-label">Profile</span><span class="meta-value">{profile_icon} {esc(profile_name)}</span></div>
<div class="meta-item"><span class="meta-label">Duration</span><span class="meta-value">{duration}</span></div>
<div class="meta-item"><span class="meta-label">Version</span><span class="meta-value">v{__version__}</span></div>
</div></div></header>
<div class="container"><div class="summary-section"><div class="summary-grid">
<div class="risk-gauge-wrapper"><div class="risk-gauge">
<svg width="160" height="160" viewBox="0 0 160 160">
<circle class="risk-gauge-bg" cx="80" cy="80" r="70"></circle>
<circle class="risk-gauge-fill" cx="80" cy="80" r="70" stroke="{score_color}" stroke-dasharray="440" stroke-dashoffset="{gauge_offset}"></circle>
</svg><div class="risk-gauge-center"><div class="risk-score-value" style="color:{score_color}">{score}</div>
<div class="risk-score-label">Security Score</div></div></div></div>
<div class="stats-row">
<div class="stat-card safe"><div class="stat-number">{counts['safe']}</div><div class="stat-label">Passed</div></div>
<div class="stat-card warning"><div class="stat-number">{counts['warning']}</div><div class="stat-label">Warnings</div></div>
<div class="stat-card critical"><div class="stat-number">{counts['critical']}</div><div class="stat-label">Critical</div></div>
<div class="stat-card info"><div class="stat-number">{counts['info']+counts['not_supported']}</div><div class="stat-label">Info</div></div>
</div></div></div></div>
<div class="toolbar"><div class="container"><div class="toolbar-inner">
<div class="search-box"><span class="search-icon">🔍</span><input type="text" id="searchInput" placeholder="Search findings..."></div>
<select class="filter-select" id="statusFilter"><option value="">All Status</option><option value="critical">🔴 Critical</option><option value="warning">🟡 Warning</option><option value="safe">🟢 Passed</option><option value="info">🔵 Info</option></select>
<select class="filter-select" id="categoryFilter"><option value="">All Categories</option>{cat_opts}</select>
<button class="btn btn-secondary" onclick="expandAll()">📂 Expand All</button>
<button class="btn btn-secondary" onclick="toggleTheme()">🌙 Theme</button>
<button class="btn btn-primary" onclick="window.print()">📄 Export PDF</button>
</div></div></div>
<div class="container"><div class="main-content">
<aside class="sidebar">
<div class="card"><div class="card-header"><span class="card-icon">📱</span><span class="card-title">Device Information</span></div>
<div class="device-grid">
<div class="device-item"><span class="device-label">Model</span><span class="device-value">{esc(device.get('model','N/A'))}</span></div>
<div class="device-item"><span class="device-label">Manufacturer</span><span class="device-value">{esc(device.get('manufacturer','N/A'))}</span></div>
<div class="device-item"><span class="device-label">Android</span><span class="device-value">{esc(device.get('android_version','N/A'))} (API {esc(device.get('sdk_level','N/A'))})</span></div>
<div class="device-item"><span class="device-label">Security Patch</span><span class="device-value">{esc(device.get('security_patch','N/A'))}</span></div>
<div class="device-item"><span class="device-label">Kernel</span><span class="device-value">{esc(device.get('kernel_version','N/A'))}</span></div>
<div class="device-item"><span class="device-label">Build Type</span><span class="device-value">{esc(device.get('build_type','N/A'))}</span></div>
<div class="device-item"><span class="device-label">Serial</span><span class="device-value">{esc(device.get('serialno','N/A'))}</span></div>
</div></div>
<div class="card"><div class="card-header"><span class="card-icon">📊</span><span class="card-title">Distribution</span></div>
<div class="chart-wrapper"><canvas id="chart"></canvas></div></div>
</aside>
<main class="findings-section"><h2>🔍 Security Findings <span class="findings-count" id="findingsCount">{len(rows)} checks</span></h2>
<div class="findings-list" id="findingsContainer">{findings}</div></main>
</div></div>
<footer class="footer"><div class="container">
<p><strong>CRISCAN</strong> - Critical Infrastructure Security Scanner v{__version__}</p>
<p>Made with ❤️ by <a href="https://github.com/IoTSRG">IoTSRG Team</a></p>
</div></footer>
<script>
new Chart(document.getElementById('chart'),{{type:'doughnut',data:{{labels:['Passed','Warning','Critical','Info'],datasets:[{{data:[{counts['safe']},{counts['warning']},{counts['critical']},{counts['info']+counts['not_supported']}],backgroundColor:['#10b981','#f59e0b','#ef4444','#3b82f6'],borderWidth:0,spacing:2}}]}},options:{{responsive:true,maintainAspectRatio:false,cutout:'65%',plugins:{{legend:{{position:'bottom',labels:{{padding:12,usePointStyle:true,font:{{size:11}},color:'#94a3b8'}}}}}}}});
function toggleFinding(h){{h.closest('.finding-card').classList.toggle('expanded')}}
function expandAll(){{const c=document.querySelectorAll('.finding-card');const all=[...c].every(x=>x.classList.contains('expanded'));c.forEach(x=>x.classList.toggle('expanded',!all))}}
function toggleTheme(){{const t=document.documentElement.getAttribute('data-theme');document.documentElement.setAttribute('data-theme',t==='light'?'dark':'light')}}
document.getElementById('searchInput').addEventListener('input',filter);
document.getElementById('statusFilter').addEventListener('change',filter);
document.getElementById('categoryFilter').addEventListener('change',filter);
function filter(){{const q=document.getElementById('searchInput').value.toLowerCase();const s=document.getElementById('statusFilter').value;const c=document.getElementById('categoryFilter').value;let n=0;
document.querySelectorAll('.finding-card').forEach(card=>{{const t=card.textContent.toLowerCase();const st=card.dataset.status;const ct=card.dataset.category;
const m=(!q||t.includes(q))&&(!s||st===s)&&(!c||ct===c);card.style.display=m?'':'none';if(m)n++}});
document.getElementById('findingsCount').textContent=n+' checks'}}
</script></body></html>'''
    
    with open(path, "w", encoding="utf-8") as f: f.write(html_doc)

def print_banner(serial, profile=None):
    print(f"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║   ██████╗██████╗ ██╗███████╗ ██████╗ █████╗ ███╗   ██╗                        ║
║  ██╔════╝██╔══██╗██║██╔════╝██╔════╝██╔══██╗████╗  ██║                        ║
║  ██║     ██████╔╝██║███████╗██║     ███████║██╔██╗ ██║                        ║
║  ██║     ██╔══██╗██║╚════██║██║     ██╔══██║██║╚██╗██║                        ║
║  ╚██████╗██║  ██║██║███████║╚██████╗██║  ██║██║ ╚████║                        ║
║   ╚═════╝╚═╝  ╚═╝╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝                        ║
║                                                                               ║
║  CRISCAN - Critical Infrastructure Security Scanner v{__version__:<22}║
║  Android Security Audit Framework for IoT | Medical | Automotive             ║
╚═══════════════════════════════════════════════════════════════════════════════╝
    """)
    if profile and profile in PROFILES:
        p = PROFILES[profile]
        print(f"  Profile: {p['icon']} {p['name']}\n  {p['description']}")
    if serial: print(f"  Target: {serial}")
    print()

def main():
    ap = argparse.ArgumentParser(description=f"{TOOL_NAME} - {TOOL_FULL}")
    ap.add_argument("--json", action="append", default=[], help="JSON check file")
    ap.add_argument("--json-dir", help="Directory with JSON checks")
    ap.add_argument("--serial", default=os.environ.get("ANDROID_SERIAL",""), help="ADB serial")
    ap.add_argument("--profile", choices=list(PROFILES.keys()), help="Audit profile")
    ap.add_argument("--out", default="criscan_reports", help="Output dir")
    ap.add_argument("--format", nargs="+", choices=["html","txt","csv","json"], default=["html","txt","csv","json"])
    ap.add_argument("--ci", action="store_true", help="CI mode")
    ap.add_argument("--critical-threshold", type=int, default=0)
    ap.add_argument("--quiet", "-q", action="store_true")
    ap.add_argument("--version", "-v", action="version", version=f"{TOOL_NAME} {__version__}")
    args = ap.parse_args()

    if not which("adb"): print("ERROR: adb not found", file=sys.stderr); sys.exit(1)
    run(["adb", "start-server"])
    
    serial = pick_default_serial((args.serial or "").strip() or None)
    if not serial: explain_adb_devices_and_exit(2)
    
    adb = ADB(serial)
    try: adb.check_connected()
    except: explain_adb_devices_and_exit(3)
    
    if not args.quiet: print_banner(serial, args.profile)
    
    checks = []
    if args.json_dir: checks.extend(load_checks_from_dir(args.json_dir))
    for p in args.json: checks.extend(load_checks_from_file(p))
    if not checks: print("ERROR: No checks", file=sys.stderr); sys.exit(1)
    
    if args.profile:
        orig = len(checks)
        checks = filter_checks_by_profile(checks, args.profile)
        if not args.quiet: print(f"[*] Profile: {len(checks)}/{orig} checks\n")
    
    def progress(i, t):
        if not args.quiet:
            pct = int((i/t)*100)
            sys.stdout.write(f"\r[{'█'*(pct//5)}{'░'*(20-pct//5)}] {pct}% ({i}/{t})")
            sys.stdout.flush()
    
    ts = time.strftime("%Y%m%d_%H%M%S")
    report_dir = os.path.join(args.out, f"audit_{ts}")
    os.makedirs(report_dir, exist_ok=True)
    
    if not args.quiet: print("[*] Collecting device info...")
    device = collect_device_info(adb)
    
    if not args.quiet: print(f"[*] Running {len(checks)} checks...\n")
    start = time.time()
    rows, counts = run_checks(adb, checks, progress)
    duration = f"{int((time.time()-start)//60)}m {int((time.time()-start)%60)}s"
    print()
    
    files = {}
    if "txt" in args.format: p=os.path.join(report_dir,"report.txt"); write_txt(p,device,rows,counts,args.profile); files["txt"]=p
    if "csv" in args.format: p=os.path.join(report_dir,"report.csv"); write_csv(p,rows); files["csv"]=p
    if "json" in args.format: p=os.path.join(report_dir,"report.json"); write_json(p,device,rows,counts,args.profile); files["json"]=p
    if "html" in args.format: p=os.path.join(report_dir,"report.html"); write_html(p,device,rows,counts,args.profile,duration); files["html"]=p
    
    print(f"\n{'='*70}\n  {TOOL_NAME} AUDIT COMPLETED\n{'='*70}")
    print(f"  Device: {device.get('model')} ({serial})")
    print(f"  Android: {device.get('android_version')} | Patch: {device.get('security_patch')}")
    print(f"{'-'*70}\n  ✓ Safe: {counts['safe']}  ⚠ Warning: {counts['warning']}  ✗ Critical: {counts['critical']}  ○ Info: {counts['info']}")
    total = counts['safe']+counts['warning']+counts['critical']
    print(f"  Pass Rate: {round((counts['safe']/total)*100,1) if total else 0}% | Duration: {duration}")
    print(f"{'-'*70}\n  Reports:")
    for fmt, path in files.items(): print(f"    [{fmt.upper()}] {path}")
    print(f"{'='*70}\n  Made with ❤️ by IoTSRG Team\n{'='*70}\n")
    
    if args.ci:
        if counts["critical"] > args.critical_threshold:
            print(f"[CI] FAILED: {counts['critical']} critical"); sys.exit(2)
        print("[CI] PASSED"); sys.exit(0)

if __name__ == "__main__": main()
